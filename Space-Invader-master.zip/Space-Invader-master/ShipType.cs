﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace SpaceInvaders
{
    enum ShipType
    {
        Bug,
        Saucer,
        Satellite,
        SpaceShip,
        star
    }
}
