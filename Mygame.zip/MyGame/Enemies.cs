﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Xml;
using System.Runtime.Remoting.Messaging;

namespace MyGame
{
    class Enemies: Form1
    {
        ///////Properties/Fields/////
        //public Direction EnemyDirection { get; set; } = Direction.Up;
        //public PictureBox picEnemy1 { get; private set; } = new PictureBox();
        //public PictureBox picEnemy2 { get; private set; } = new PictureBox();
        //public PictureBox picEnemy3 { get; private set; } = new PictureBox();
        //public PictureBox picPlayer { get; private set; } = new PictureBox();

        //public Timer EnemyMovement { get; set; }
        

        //public int EnemySpeed { get; set; } //Default speed
        //public int EnemySpawned { get; private set; }
        //public int EnemyDamage { get; private set; }

        //public bool RollAttackUp { get; private set; }
        //public bool RollAttackDown { get; private set; }

        //public Direction SkeletonShootDirection { get; set; }

        ///////Constructor not needed/////

        ///////Methods/////
        //public void SpawnEnemy(Form form, PictureBox player) //Form to put enemy on screen, player parameter to check distance between enemy and player when spawning 
        //{
        //    picPlayer = player;
        //    Random rand = new Random();
        //    int posX;
        //    int posY;
        //    int enemyToSpawn = rand.Next(1, 4);
  
            
        //    posX = rand.Next(24, form.ClientSize.Width - 50); //Gets random number for enemy x location inside form
        //    posY = rand.Next(21, form.ClientSize.Height - 70); //Gets random number for enemy y location inside form
        //    if (Math.Abs(posX - picPlayer.Left) < 50) //Checks if Enemy spawnpoint is less than 50 pixels away from player
        //    {
        //        if (picPlayer.Left > form.ClientSize.Width / 2)
        //            posX -= 200; //Spawns enemy to the left if player is on the right side of screen
        //        else
        //            posX += 200;//Spawns enemy to the right if player is on the Left side of screen

        //        if (picPlayer.Top > form.ClientSize.Height / 2)
        //            posY -= 50; //Spawns enemy above if player is on the Bottom half of screen
        //        else
        //            posY += 50; //Spawns enemy below if player is on the Top side half of screen
        //    }

        //    picEnemy1.Left = posX;
        //    picEnemy1.Top = posY;

        //    picEnemy2.Left = posX;
        //    picEnemy2.Top = posY;

        //    picEnemy3.Left = posX;
        //    picEnemy3.Top = posY;

        //    if (enemyToSpawn == 1)
        //    {
        //        EnemySpeed = rand.Next(40, 71);
        //        picEnemy1.Image = Properties.Resources.Enemy1;
        //        picEnemy1.SizeMode = PictureBoxSizeMode.AutoSize;
        //        picEnemy1.BackColor = Color.Transparent;
        //        form.Controls.Add(picEnemy1);
        //        picEnemy1.BringToFront();
        //        EnemySpawned = 1;
        //    }
        //    else if (enemyToSpawn == 2)
        //    {

        //        EnemySpeed = rand.Next(25, 56);
        //        picEnemy2.Image = Properties.Resources.Enemy2;
        //        picEnemy2.SizeMode = PictureBoxSizeMode.AutoSize;
        //        picEnemy2.BackColor = Color.Transparent;
        //        form.Controls.Add(picEnemy2);
        //        picEnemy2.BringToFront();
        //        EnemySpawned = 2;
        //    }
        //    else if (enemyToSpawn == 3)
        //    {
        //        EnemySpeed = rand.Next(65, 91);
        //        picEnemy3.Image = Properties.Resources.Enemy3;
        //        picEnemy3.SizeMode = PictureBoxSizeMode.AutoSize;
        //        picEnemy3.BackColor = Color.Transparent;
        //        form.Controls.Add(picEnemy3);
        //        picEnemy3.BringToFront();
        //        EnemySpawned = 3;
        //    }

        //    EnemyMovement = new Timer();
        //    EnemyMovement.Interval = EnemySpeed;
        //    EnemyMovement.Tick += new EventHandler(EnemyMovementEvent);
        //    EnemyMovement.Start();
        //}

        //private async void EnemyMovementEvent(object sender, EventArgs e)
        //{
        //    if (EnemySpawned == 1) //Ball-like enemy
        //    {
        //        if (picPlayer.Left - 5 > picEnemy1.Left && !RollAttackUp && !RollAttackDown) //Moves right when not roll attacking
        //        {
        //            picEnemy1.Left += 5;
        //        }
        //        else if (picPlayer.Left + 5 < picEnemy1.Left && !RollAttackUp && !RollAttackDown) //Moves left when not roll attacking
        //        {
        //            picEnemy1.Left -= 5;
        //        }

        //        if (Math.Abs(picPlayer.Left - picEnemy1.Left) < 10 && picPlayer.Top < picEnemy1.Top && !RollAttackDown) //Checks to see if enemy is aligned with player vertically and starts attack
        //            RollAttackUp = true;
        //        else if (Math.Abs(picPlayer.Left - picEnemy1.Left) < 10 && picPlayer.Top > picEnemy1.Top && !RollAttackUp)
        //            RollAttackDown = true;

        //        if (RollAttackUp) //If player is above, it rolls up
        //        {
        //            picEnemy1.Top -= 25;
        //            if (picEnemy1.Top <= 30 && RollAttackUp) //Stops rolling once wall is hit
        //            {
        //                RollAttackUp = false;
        //                EnemyMovement.Stop();
        //                await Task.Delay(1500);
        //                EnemyMovement.Start();
        //            }
        //        }
        //        else if (RollAttackDown) //If player is above, it rolls up
        //        {
        //            picEnemy1.Top += 25;
        //            if (picEnemy1.Top + picEnemy1.Height >= 439 && RollAttackDown) //Stops rolling once wall is hit
        //            {
        //                RollAttackDown = false;
        //                EnemyMovement.Stop();
        //                await Task.Delay(1500);
        //                EnemyMovement.Start();
        //            }
        //        }

        //        //Damage to player on contact
        //        if (picEnemy1.Bounds.IntersectsWith(picPlayer.Bounds))
        //        {
        //            EnemyDamage = 30;
        //        }
        //    }

        //    else if (EnemySpawned == 2) //Skeleton enemy
        //    {
        //        if (Math.Abs(picPlayer.Left - picEnemy2.Left) < 200 && picPlayer.Left > picEnemy2.Left && picEnemy2.Left >= 24) //Backs off when player is close (left side)
        //            picEnemy2.Left -= 5;
        //        else if (Math.Abs(picPlayer.Left - picEnemy2.Left) < 200 && picPlayer.Left < picEnemy2.Left && picEnemy2.Left <= 730) //Backs off when player is close (right side)
        //            picEnemy2.Left += 5;
        //        else if (Math.Abs(picPlayer.Left - picEnemy2.Left) > 250) //Moves towards player if too far
        //        {
        //            if (picPlayer.Left > picEnemy2.Left)
        //                picEnemy2.Left += 5;
        //            else
        //                picEnemy2.Left -= 5;
        //        }

        //        //Vertical bounce movement
        //        if (EnemyDirection == Direction.Up)
        //        {
        //            picEnemy2.Top -= 10;
        //            if (picEnemy2.Top <= 21)
        //                EnemyDirection = Direction.Down;
        //        }
        //        else if (EnemyDirection == Direction.Down)
        //        {
        //            picEnemy2.Top += 10;
        //            if (picEnemy2.Top >= 360)
        //                EnemyDirection = Direction.Up;
        //        }

        //        if (picPlayer.Left >= picEnemy2.Left)
        //            SkeletonShootDirection = Direction.Right;
        //        else if (picPlayer.Left < picEnemy2.Left)
        //            SkeletonShootDirection = Direction.Left;

        //        //Damage to player on contact
        //        if (picEnemy2.Bounds.IntersectsWith(picPlayer.Bounds))
        //        {
        //            EnemyDamage = 10;
        //        }
        //    }

        //    else if (EnemySpawned == 3) //Ghost Reaper enemy
        //    {
        //        //Follows player horizontally
        //        if (picPlayer.Left - 5 > picEnemy3.Left) 
        //            picEnemy3.Left += 5;
        //        else if (picPlayer.Left + 5 < picEnemy3.Left)
        //            picEnemy3.Left -= 5;

        //        //Follows player Vertically as well
        //        if (picPlayer.Top - 5 > picEnemy3.Top)
        //            picEnemy3.Top += 5;
        //        else if (picPlayer.Top + 5 < picEnemy3.Top)
        //            picEnemy3.Top -= 5;

        //        //Damage to player on contact
        //        if (picEnemy2.Bounds.IntersectsWith(picPlayer.Bounds))
        //        {
        //            EnemyDamage = 40;
        //        }
        //    }
        //}
     
        //public int HealthLeft(ProgressBar Health)
        //{
        //    Health.Value -= EnemyDamage;
        //    return Health.Value;
        //}
    }
}