﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;

namespace MyGame
{
    class Projectiles
    {
        /////Properties/Fields/////
        public PictureBox picPlayerLaser { get; private set; }
        public PictureBox picPlayerTeleport { get; private set; }
        public PictureBox picBone { get; private set; }

        public Direction ProjectileDirection { get; private set; }
        public Timer ShootSpeed { get; set; }

        public int ProjectileNumber { get; private set; }
        public int ProjectileLocationX { get; set; }
        public int ProjectileLocationY { get; set; }
        public int ProjectileSpeed { get; set; } = 20;

        public int ClientSizeX { get; private set; }
        public int ClientSizeY { get; private set; }

        public bool ProjectileHitWall { get; set; }
        public bool XKeyReleased { get; set; }

        ///////Constructor not needed/////
        
        /////Methods/////
        public void MakeProjectile(Form form, Direction shotDirection, int projectileNumber)
        {
            ProjectileNumber = projectileNumber;
            ClientSizeX = form.ClientSize.Width;
            ClientSizeY = form.ClientSize.Height;

            if (ProjectileNumber == 1)
            {
                picPlayerLaser = new PictureBox();
                picPlayerLaser.Tag = "Laser";
                picPlayerLaser.BackColor = Color.Red;

                picPlayerLaser.Left = ProjectileLocationX;
                picPlayerLaser.Top = ProjectileLocationY;

                form.Controls.Add(picPlayerLaser);
                picPlayerLaser.BringToFront();

                //Gets direction of where you are shooting and rotates the picturebox based on that
                ProjectileDirection = shotDirection;
                if (ProjectileDirection == Direction.Left || ProjectileDirection == Direction.Right)
                    picPlayerLaser.Size = new Size(20, 5);
                else if (ProjectileDirection == Direction.Up || ProjectileDirection == Direction.Down)
                    picPlayerLaser.Size = new Size(5, 20);
            }

            else if (ProjectileNumber == 2)
            {
                picPlayerTeleport = new PictureBox();
                picPlayerTeleport.Tag = "Teleport";
                picPlayerTeleport.Image = Properties.Resources.Target;
                picPlayerTeleport.BackColor = Color.Transparent;
                picPlayerTeleport.SizeMode = PictureBoxSizeMode.AutoSize;

                picPlayerTeleport.Left = ProjectileLocationX;
                picPlayerTeleport.Top = ProjectileLocationY;

                form.Controls.Add(picPlayerTeleport);
                picPlayerTeleport.BringToFront();

                //Gets direction of where you are shooting and rotates the picturebox based on that
                ProjectileDirection = shotDirection;

                ProjectileSpeed = 30;
            }

            else if (ProjectileNumber == 3)
            {
                picBone = new PictureBox();
                picBone.Tag = "Bone";
                picBone.Image = Properties.Resources.Bone;
                picBone.SizeMode = PictureBoxSizeMode.AutoSize;
                picBone.BackColor = Color.Transparent;

                picBone.Left = ProjectileLocationX;
                picBone.Top = ProjectileLocationY;

                form.Controls.Add(picBone);

                ProjectileSpeed = 30;

                //Direction of shot
                ProjectileDirection = shotDirection;
            }

            ShootSpeed = new Timer();
            ShootSpeed.Interval = ProjectileSpeed;
            ShootSpeed.Tick += new EventHandler(ShootSpeedEvent);
            ShootSpeed.Start();
        }

        private void ShootSpeedEvent(object sender, EventArgs e)
        {
            //Shoots Projectile in direction your facing at appropriate speed
            if (ProjectileNumber == 1)
            {
                if (ProjectileDirection == Direction.Up)
                {
                    picPlayerLaser.Top -= ProjectileSpeed;
                }

                else if (ProjectileDirection == Direction.Down)
                {
                    picPlayerLaser.Top += ProjectileSpeed;
                }

                else if (ProjectileDirection == Direction.Left)
                {
                    picPlayerLaser.Left -= ProjectileSpeed;
                }

                else if (ProjectileDirection == Direction.Right)
                {
                    picPlayerLaser.Left += ProjectileSpeed;
                }

                //Destroys Projectile when out of form
                if (picPlayerLaser.Top < 24 || picPlayerLaser.Top > ClientSizeY - 24 || picPlayerLaser.Left < 24 || picPlayerLaser.Left > ClientSizeX - 24)
                {
                    ShootSpeed.Stop();
                    ShootSpeed.Dispose();
                    ShootSpeed = null;

                    picPlayerLaser.Dispose();
                    picPlayerLaser = null;
                }
            }
            else if (ProjectileNumber == 2)
            {
                if (ProjectileDirection == Direction.Up)
                {
                    picPlayerTeleport.Top -= 12;
                }

                else if (ProjectileDirection == Direction.Down)
                {
                    picPlayerTeleport.Top += 12;
                }

                else if (ProjectileDirection == Direction.Left)
                {
                    picPlayerTeleport.Left -= 12;
                }

                else if (ProjectileDirection == Direction.Right)
                {
                    picPlayerTeleport.Left += 12;
                }

                //Destroys Projectile when out of form or key released
                if (picPlayerTeleport.Top < 24 || picPlayerTeleport.Top > ClientSizeY - 24 || picPlayerTeleport.Left < 24 || picPlayerTeleport.Left > ClientSizeX - 24 || XKeyReleased)
                {
                    ShootSpeed.Stop();
                    ShootSpeed.Dispose();
                    ShootSpeed = null;

                    picPlayerTeleport.Dispose();
                    picPlayerTeleport = null;

                    if (!XKeyReleased)
                        ProjectileHitWall = true;
                }
            }

            else if (ProjectileNumber == 3)
            {
                if (ProjectileDirection == Direction.Left)
                {
                    picBone.Left -= 12;
                }

                else if (ProjectileDirection == Direction.Right)
                {
                    picBone.Left += 12;
                }

                //Destroys Projectile when out of form 
                if (picBone.Top < 24 || picBone.Top > ClientSizeY - 24 || picBone.Left < 24 || picBone.Left > ClientSizeX - 24)
                {
                    ShootSpeed.Stop();
                    ShootSpeed.Dispose();
                    ShootSpeed = null;

                    picBone.Dispose();
                    picBone = null;
                }
            }
        }
    }
}