﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGame
{
    enum Direction { Idle, Up, Down, Left, Right } //Directions of movement
    enum GameState { OutGame, InGame}
    public partial class Form1 : Form
    {
        DialogueManager dialogue;
        Rooms rooms;
        Projectiles teleport;

        Random rand = new Random();

        PictureBox pichealthKit;
        PictureBox picPortal;

        Direction walkDirection = Direction.Idle;
        Direction facingDirection = Direction.Down;
        GameState gameState = GameState.OutGame;

        int speed = 6; //Speed of character
        int health = 100; //Player health

        int originalShotDelay = 35;
        int shotDelay = 0;

        int originalIFrames = 40;
        int IFrames = 0;

        bool healthSpawned = false;
        bool cutscene1;
        bool cutscene2;

        //Enemy Variables
        List<PictureBox> enemyList = new List<PictureBox>();

        int originalSkeletonShotDelay = 40;
        int skeletonShotDelay = 40;

        int[] enemyDamage = { 35, 20, 50 }; //Change values if game is too hard for you (default: 35, 20, 50)
        int enemyKillCount = 0;

        int amountOfEnemies;

        bool objectiveComplete;

        public Form1()
        {
            InitializeComponent();
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            BackgroundImage = Properties.Resources.Black;

            btnStart.Visible = false;
            btnQuit.Visible = false;
            lblWarning.Visible = false;
            lblGameOver.Visible = false;
            btnControls.Visible = false;
            btnMainMenu.Visible = false;
            lblTitle.Visible = false;
            btnBack.Visible = false;
            cutscene1 = true;

            await Task.Delay(2000);
            gameState = GameState.OutGame;
            dialogue = new DialogueManager(this);
            dialogue.SetDialogue(this, DialogueState.Intro);
            dialogue.ShowSentence();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private async void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Z && dialogue != null && gameState == GameState.OutGame)
            {
                if (dialogue.Next)
                {
                    //If a sentence is available, it will go to it by pressing "z"
                    dialogue.NextSentence();
                }

                //When the dialogue is finished, the game will start on next "z" press
                else if (dialogue.SpeechFinished && cutscene1)
                {
                    cutscene1 = false;
                    dialogue.lblDialogue.Dispose();
                    dialogue.state = DialogueState.None;
                    dialogue.SpeechFinished = false;
                    startGame();
                }

                //When the dialogue is finished, the game will end on next "z" press
                else if (dialogue.SpeechFinished && cutscene2)
                {
                    cutscene2 = false;
                    dialogue.lblDialogue.Dispose();
                    dialogue.state = DialogueState.None;
                    dialogue.SpeechFinished = false;
                    gameState = GameState.OutGame;
                    picCharacter.Image = Properties.Resources.CharacterSpriteEnd;

                    await Task.Delay(4000);
                    GameFinished();
                }
            }

            else if (e.KeyCode == Keys.Z && gameState == GameState.InGame && shotDelay <= 0) //Laser shot
            {
                //spawns projectile from your location
                Projectiles laser = new Projectiles()
                {
                    ProjectileLocationX = picCharacter.Left + 10,
                    ProjectileLocationY = picCharacter.Top + 10
                };

                laser.MakeProjectile(this, facingDirection, 1);

                picCharacter.Image = Properties.Resources.CharacterSpriteShooting;
                shotDelay = originalShotDelay;
            }

            else if (e.KeyCode == Keys.X && gameState == GameState.InGame && shotDelay <= 0) //Teleport shot
            {
                teleport = new Projectiles()
                {
                    ProjectileLocationX = picCharacter.Left + 10,
                    ProjectileLocationY = picCharacter.Top + 10
                };

                teleport.MakeProjectile(this, facingDirection, 2);
                picCharacter.Image = Properties.Resources.CharacterSpriteShooting;
                shotDelay = 1000;
            }

            //Movement inputs
            if (e.KeyCode == Keys.Up)
            {
                walkDirection = Direction.Up;
                facingDirection = walkDirection;
            }

            if (e.KeyCode == Keys.Down)
            {
                walkDirection = Direction.Down;
                facingDirection = walkDirection;
            }

            if (e.KeyCode == Keys.Left)
            {
                walkDirection = Direction.Left;
                facingDirection = walkDirection;
            }

            if (e.KeyCode == Keys.Right)
            {
                walkDirection = Direction.Right;
                facingDirection = walkDirection;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (teleport != null && teleport.picPlayerTeleport == null && teleport.ProjectileHitWall) //Checks if laser collided with wall before release
            {                                                                                               //if yes, player doesn't teleport (can't teleport to null projectile so it prevents crash)
                shotDelay = originalShotDelay - 15; //Sets the delay back to original (no spam click)
                teleport.ProjectileHitWall = false; //Sets back to false when complete
            }
            else if (e.KeyCode == Keys.X && gameState == GameState.InGame && teleport != null && teleport.picPlayerTeleport != null)
            {
                //Spawn to location of shot when x is let go
                if (teleport.picPlayerTeleport.Top > ClientSize.Height - 80 && teleport.ProjectileDirection == Direction.Down)
                    picCharacter.Location = new Point(picCharacter.Left, ClientSize.Height - 85);
                else
                {
                    picCharacter.Top = teleport.picPlayerTeleport.Top - 10;
                    picCharacter.Left = teleport.picPlayerTeleport.Left - 10;
                }


                //Indicates that you let go of X before the bullet collided with the wall
                teleport.XKeyReleased = true;
                shotDelay = originalShotDelay - 15; //Sets the delay back to original (no spam click)
            }

            if (e.KeyCode == Keys.Up)
            {
                walkDirection = Direction.Idle;
            }

            if (e.KeyCode == Keys.Down)
            {
                walkDirection = Direction.Idle;
            }

            if (e.KeyCode == Keys.Left)
            {
                walkDirection = Direction.Idle;
            }

            if (e.KeyCode == Keys.Right)
            {
                walkDirection = Direction.Idle;
            }
        }

        private async void tmrGame_Tick(object sender, EventArgs e)
        {
            if (rooms != null && gameState == GameState.InGame)
            {
                //Move up
                if (walkDirection == Direction.Up)
                {
                    if (picCharacter.Top <= 21 && picCharacter.Left < 367 || picCharacter.Top <= 21 && picCharacter.Left + picCharacter.Width > 427) //Prevents walking on borders
                    {
                        walkDirection = Direction.Idle;
                    }

                    else
                    {
                        if (rooms.CurrentRoomY == 0 && picCharacter.Top <= 21 || picPortal != null && picCharacter.Top <= 21) //Does not allow going to a new room if you are in the final room of that direction
                            walkDirection = Direction.Idle;                                                                //Also prevents you from leaving portal room once found
                        else
                            picCharacter.Top -= speed; //Goes through narrow space in middle of wall if able to
                    }
                }

                //Move down
                if (walkDirection == Direction.Down)
                {
                    if (picCharacter.Top + picCharacter.Height >= 439 && picCharacter.Left < 367 || picCharacter.Top + picCharacter.Height >= 439 && picCharacter.Left + picCharacter.Width > 427) //Prevents walking on borders
                    {
                        walkDirection = Direction.Idle; //Doesn't go further down (prevents going on borders)
                    }
                    else
                    {
                        if (rooms.CurrentRoomY == rooms.RoomGridY && picCharacter.Top + picCharacter.Height >= 439 || picPortal != null && picCharacter.Top + picCharacter.Height >= 439) //Does not allow going to a new room if you are in the final room of that direction
                            walkDirection = Direction.Idle;                                                                                                                            //Also prevents you from leaving portal room once found
                        else
                            picCharacter.Top += speed; //Goes through narrow space in middle of wall if able to
                    }
                }

                //Move left
                if (walkDirection == Direction.Left)
                {
                    if (picCharacter.Left <= 24 && picCharacter.Top < 178 || picCharacter.Left <= 24 && picCharacter.Top + picCharacter.Height > 283) //Prevents walking on borders
                    {
                        walkDirection = Direction.Idle; //Doesn't go further left (prevents going on borders)
                    }
                    else
                    {
                        if (rooms.CurrentRoomX == 0 && picCharacter.Left <= 24 || picPortal != null && picCharacter.Left <= 24) //Does not allow going to a new room if you are in the final room of that direction
                            walkDirection = Direction.Idle;                                                                  //Also prevents you from leaving portal room once found
                        else
                            picCharacter.Left -= speed; //Goes through narrow space in middle of wall if able to
                    }
                }

                //Move right
                if (walkDirection == Direction.Right)
                {
                    if (picCharacter.Left >= 744 && picCharacter.Top < 178 || picCharacter.Left >= 744 && picCharacter.Top + picCharacter.Height > 283) //Prevents walking on borders
                    {
                        walkDirection = Direction.Idle; //Doesn't go further right (prevents going on borders)
                    }
                    else
                    {
                        if (rooms.CurrentRoomX == rooms.RoomGridX && picCharacter.Left >= 744 || picPortal != null && picCharacter.Left >= 744) //Does not allow going to a new room if you are in the final room of that direction
                            walkDirection = Direction.Idle;                                                                                  //Also prevents you from leaving portal room once found
                        else
                            picCharacter.Left += speed; //Goes through narrow space in middle of wall if able to
                    }
                }

                //Keeps track of what room your in and lets you move to other rooms 

                //Going up a room
                if (picCharacter.Top <= 0 && picCharacter.Left >= 367 && picCharacter.Left + picCharacter.Width <= 427) //Walk through the little opening
                {
                    if (rooms.CurrentRoomY > 0)
                    {
                        rooms.CurrentRoomY -= 1;
                        picCharacter.Location = new Point(picCharacter.Location.X, ClientSize.Height - picCharacter.Height - 2);

                        foreach (PictureBox x in enemyList) //Removes enemies when you go to new room
                        {
                            Controls.Remove(x);
                            x.Dispose();
                        }

                        //Spawns new enemies
                        amountOfEnemies = rand.Next(2, 6); //Will spawn 2-5 enemies per room
                        for (int i = 0; i < amountOfEnemies; i++)
                        {
                            SpawnEnemy(); //Calls enemy spawn method
                            picCharacter.BringToFront();
                        }

                        //Changes cave background based on where you are
                        if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveULR;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == 0)
                            BackgroundImage = Properties.Resources.CaveURD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX)
                            BackgroundImage = Properties.Resources.CaveULD;
                        else if (rooms.CurrentRoomX > 0 && rooms.CurrentRoomX < rooms.RoomGridX && rooms.CurrentRoomY > 0 && rooms.CurrentRoomY < rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.Cave;
                    }
                }

                //Going down a room
                if (picCharacter.Top + picCharacter.Height > ClientSize.Height && picCharacter.Left > 367 && picCharacter.Left + picCharacter.Width < 427) //Walk through the little opening
                {
                    if (rooms.CurrentRoomY < rooms.RoomGridY)
                    {
                        rooms.CurrentRoomY += 1;
                        picCharacter.Location = new Point(picCharacter.Location.X, 2);

                        foreach (PictureBox x in enemyList) //Removes enemies when you go to new room
                        {
                            Controls.Remove(x);
                            x.Dispose();
                        }

                        //Spawns new enemies
                        amountOfEnemies = rand.Next(2, 6); //Will spawn 2-5 enemies per room
                        for (int i = 0; i < amountOfEnemies; i++)
                        {
                            SpawnEnemy(); //Calls enemy spawn method
                            picCharacter.BringToFront();
                        }

                        //Changes cave background based on where you are
                        if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveULR;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == 0)
                            BackgroundImage = Properties.Resources.CaveURD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX)
                            BackgroundImage = Properties.Resources.CaveULD;
                        else if (rooms.CurrentRoomX > 0 && rooms.CurrentRoomX < rooms.RoomGridX && rooms.CurrentRoomY > 0 && rooms.CurrentRoomY < rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.Cave;
                    }
                }

                //Going left a room
                if (picCharacter.Left <= 0 && picCharacter.Top >= 178 && picCharacter.Top + picCharacter.Height <= 283) //Walk through the little opening
                {
                    if (rooms.CurrentRoomX > 0)
                    {
                        rooms.CurrentRoomX -= 1;
                        picCharacter.Location = new Point(ClientSize.Width - picCharacter.Width - 2, picCharacter.Location.Y);

                        foreach (PictureBox x in enemyList) //Removes enemies when you go to new room
                        {
                            Controls.Remove(x);
                            x.Dispose();
                        }

                        //Spawns new enemies
                        amountOfEnemies = rand.Next(2, 6); //Will spawn 2-5 enemies per room
                        for (int i = 0; i < amountOfEnemies; i++)
                        {
                            SpawnEnemy(); //Calls enemy spawn method
                            picCharacter.BringToFront();
                        }

                        //Changes cave background based on where you are
                        if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == 0)
                            BackgroundImage = Properties.Resources.CaveURD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveULR;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX)
                            BackgroundImage = Properties.Resources.CaveULD;
                        else if (rooms.CurrentRoomX > 0 && rooms.CurrentRoomX < rooms.RoomGridX && rooms.CurrentRoomY > 0 && rooms.CurrentRoomY < rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.Cave;
                    }
                }

                //Going right a room
                if (picCharacter.Left + picCharacter.Width >= ClientSize.Width && picCharacter.Top >= 178 && picCharacter.Top + picCharacter.Height <= 283) //Walk through the little opening
                {
                    if (rooms.CurrentRoomX < rooms.RoomGridX)
                    {
                        rooms.CurrentRoomX += 1;
                        picCharacter.Location = new Point(2, picCharacter.Location.Y);

                        foreach (PictureBox x in enemyList) //Removes enemies when you go to new room
                        {
                            Controls.Remove(x);
                            x.Dispose();
                        }

                        //Spawns new enemies
                        amountOfEnemies = rand.Next(2, 6); //Will spawn 2-5 enemies per room
                        for (int i = 0; i < amountOfEnemies; i++)
                        {
                            SpawnEnemy(); //Calls enemy spawn method
                            picCharacter.BringToFront();
                        }

                        //Changes cave background based on where you are
                        if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX)
                            BackgroundImage = Properties.Resources.CaveULD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLD;
                        else if (rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveLRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUL;
                        else if (rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveULR;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                            BackgroundImage = Properties.Resources.CaveRD;
                        else if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.CaveUR;
                        else if (rooms.CurrentRoomX == 0)
                            BackgroundImage = Properties.Resources.CaveURD;
                        else if (rooms.CurrentRoomX > 0 && rooms.CurrentRoomX < rooms.RoomGridX && rooms.CurrentRoomY > 0 && rooms.CurrentRoomY < rooms.RoomGridY)
                            BackgroundImage = Properties.Resources.Cave;
                    }
                }
                //Tells you what room you are in
                lblRoom.Visible = true;
                lblRoom.Text = "x: " + rooms.CurrentRoomX + " y: " + rooms.CurrentRoomY;

                //Enemy script
                foreach (Control x in Controls)
                {
                    if (x is PictureBox && x.Tag.ToString() == "Evil Sphere") //First enemy/////////////////////////////////////////////
                    {
                        //Enemy gets hit 
                        foreach (Control l in Controls) //l represents laser
                        {
                            if (l is PictureBox && l.Tag.ToString() == "Laser")
                            {
                                if (x.Bounds.IntersectsWith(l.Bounds)) //hits enemy
                                {
                                    //Removes enemy
                                    Controls.Remove(x);
                                    x.Dispose();

                                    //Removes laser
                                    Controls.Remove(l);
                                    l.Dispose();

                                    //Updates amount of enemies defeated
                                    enemyKillCount++;
                                    lblKills.Text = "Enemies Defeated: " + enemyKillCount;
                                }
                            }
                        }

                        //Moves right
                        if (picCharacter.Left - 5 > x.Left)
                        {
                            x.Left += 3;
                        }
                        //Moves left
                        else if (picCharacter.Left + 5 < x.Left)
                        {
                            x.Left -= 3;
                        }

                        //Checks to see if enemy is aligned with player vertically when below player and starts attack
                        if (Math.Abs(picCharacter.Left - x.Left) < 10 && picCharacter.Top + 3 < x.Top)
                            x.Top -= 6;
                        //Checks to see if enemy is aligned with player vertically when above player and starts attack
                        else if (Math.Abs(picCharacter.Left - x.Left) < 10 && picCharacter.Top - 3 > x.Top)
                            x.Top += 6;


                        //Damage to player on contact with enemy
                        if (x.Bounds.IntersectsWith(picCharacter.Bounds) && health - enemyDamage[0] > 0 && IFrames <= 0)
                        {
                            health -= enemyDamage[0];
                            IFrames = originalIFrames;
                        }
                        else if (x.Bounds.IntersectsWith(picCharacter.Bounds) && IFrames <= 0)
                        {
                            health = 0;
                            GameOver();
                        }
                    }

                    else if (x is PictureBox && x.Tag.ToString() == "Skeleton") //Second Enemy////////////////////////////////////////
                    {
                        //Enemy gets hit 
                        foreach (Control l in Controls) //l represents laser
                        {
                            if (l is PictureBox && l.Tag.ToString() == "Laser")
                            {
                                if (x.Bounds.IntersectsWith(l.Bounds)) //hits enemy
                                {
                                    //Removes enemy
                                    Controls.Remove(x);
                                    x.Dispose();

                                    //Removes laser
                                    Controls.Remove(l);
                                    l.Dispose();

                                    //Updates amount of enemies defeated
                                    enemyKillCount++;
                                    lblKills.Text = "Enemies Defeated: " + enemyKillCount;
                                }
                            }
                        }

                        //Backs off when player is close (left side)
                        if (Math.Abs(picCharacter.Left - x.Left) < 200 && picCharacter.Left > x.Left && x.Left >= 24)
                            x.Left -= 5;
                        //Backs off when player is close (right side)
                        else if (Math.Abs(picCharacter.Left - x.Left) < 200 && picCharacter.Left < x.Left && x.Left <= 730)
                            x.Left += 5;
                        //Moves towards player if too far
                        else if (Math.Abs(picCharacter.Left - x.Left) > 250)
                        {
                            if (picCharacter.Left > x.Left)
                                x.Left += 5; //go right
                            else
                                x.Left -= 5; //go left
                        }

                        //Vertical movement
                        if (picCharacter.Top + 3 < x.Top)
                            x.Top -= 3;
                        else if (picCharacter.Top - 3 > x.Top)
                            x.Top += 3;

                        //Shooting
                        if (skeletonShotDelay <= 0)
                        {
                            Projectiles bone = new Projectiles();
                            bone.ProjectileLocationX = x.Left + 10;
                            bone.ProjectileLocationY = x.Top + 30;

                            if (picCharacter.Left > x.Left && skeletonShotDelay <= 0)
                                bone.MakeProjectile(this, Direction.Right, 3);
                            if (picCharacter.Left < x.Left && skeletonShotDelay <= 0)
                                bone.MakeProjectile(this, Direction.Left, 3);

                            picCharacter.BringToFront();

                            skeletonShotDelay = originalSkeletonShotDelay;
                        }
                        else
                        {
                            skeletonShotDelay--;
                        }

                        //Checks if bone hit player and deals damage
                        foreach (Control b in Controls)
                        {
                            if (b is PictureBox && b.Tag.ToString() == "Bone") //b represents bone
                            {
                                if (b.Bounds.IntersectsWith(picCharacter.Bounds) && health - enemyDamage[1] > 0 && IFrames <= 0)
                                {
                                    health -= enemyDamage[1];
                                    IFrames = originalIFrames; //Resets iFrames on hit
                                }
                                else if (b.Bounds.IntersectsWith(picCharacter.Bounds) && IFrames <= 0)
                                {
                                    health = 0;
                                    GameOver();
                                }
                            }
                        }
                    }

                    else if (x is PictureBox && x.Tag.ToString() == "Ghost") //Third Enemy////////////////////////////////////////
                    {
                        //Enemy gets hit 
                        foreach (Control l in Controls) //l represents laser
                        {
                            if (l is PictureBox && l.Tag.ToString() == "Laser")
                            {
                                if (x.Bounds.IntersectsWith(l.Bounds)) //hits enemy
                                {
                                    //Removes enemy
                                    Controls.Remove(x);
                                    x.Dispose();

                                    //Removes laser
                                    Controls.Remove(l);
                                    l.Dispose();

                                    //Updates amount of enemies defeated
                                    enemyKillCount++;
                                    lblKills.Text = "Enemies Defeated: " + enemyKillCount;
                                }
                            }
                        }

                        //Horizontal movement
                        if (picCharacter.Left + 3 < x.Left)
                            x.Left -= 2;
                        else if (picCharacter.Left - 3 > x.Left)
                            x.Left += 2;

                        //Vertical movement
                        if (picCharacter.Top + 3 < x.Top)
                            x.Top -= 2;
                        else if (picCharacter.Top - 3 > x.Top)
                            x.Top += 2;

                        //Damage to player on contact with enemy
                        if (x.Bounds.IntersectsWith(picCharacter.Bounds) && health - enemyDamage[2] > 0 && IFrames <= 0) //hits on player
                        {
                            health -= enemyDamage[2];
                            IFrames = originalIFrames;
                        }
                        else if (x.Bounds.IntersectsWith(picCharacter.Bounds) && IFrames <= 0) //Last hit before death
                        {
                            health = 0;
                            GameOver();
                        }
                    }
                }

                //sets health bar to health variable amount
                pBarHealth.Value = health;

                //your iFrames after getting hit (delay before you can get hit again)
                if (IFrames > 0)
                {
                    IFrames--;
                    picCharacter.Image = Properties.Resources.CharacterSpriteHit;
                }

                //Projectiles can only be shot when ShotDelay reaches 0 or less
                shotDelay--;
                
                //Sprite goes back to normal when shot delay is finished
                if (shotDelay <= 0 && IFrames <= 0)
                    picCharacter.Image = Properties.Resources.CharacterSprite;

                //Health kit spawns every 20 kills until 80 kills
                if (enemyKillCount == 20 && !healthSpawned || enemyKillCount == 40 && !healthSpawned || enemyKillCount == 60 && !healthSpawned || enemyKillCount == 80 && !healthSpawned)
                {
                    //Remoevs any pre-existing healthKits (prevents having more than one on screen at once)
                    if (pichealthKit != null)
                    {
                        Controls.Remove(pichealthKit);
                        pichealthKit.Dispose();
                    }

                    pichealthKit = new PictureBox();
                    pichealthKit.SizeMode = PictureBoxSizeMode.AutoSize;
                    pichealthKit.BackColor = Color.Transparent;
                    pichealthKit.Image = Properties.Resources.Health;
                    pichealthKit.Tag = "Heal";
                    pichealthKit.Location = new Point(rand.Next(24, ClientSize.Width - 40), rand.Next(24, ClientSize.Height - 40));
                    Controls.Add(pichealthKit);
                    healthSpawned = true;
                }
                else if (enemyKillCount == 21 || enemyKillCount == 41 || enemyKillCount == 61 || enemyKillCount == 81)
                    healthSpawned = false;

                //Health kit interaction on contact with it
                if (pichealthKit != null)
                {
                    if (picCharacter.Bounds.IntersectsWith(pichealthKit.Bounds))
                    {
                        health = 100;
                        pichealthKit.Dispose();
                        Controls.Remove(pichealthKit);
                    }
                }

                //Updates objective at 80 kills
                if (enemyKillCount == 80)
                {
                    lblObjective.Text = "Collect your reward: FIND THE LEADER   x:" + rooms.PortalRoomX + " y:" + rooms.PortalRoomY;
                    objectiveComplete = true;
                }
                //Checks if you reached the Final room after the 80 kills
                if (objectiveComplete && rooms.CurrentRoomX == rooms.PortalRoomX && rooms.CurrentRoomY == rooms.PortalRoomY)
                {
                    foreach (PictureBox x in enemyList)
                        Controls.Remove(x);

                    //Deletes any health kit on screen when you get to this room
                    if (pichealthKit != null)
                    {
                        Controls.Remove(pichealthKit);
                        pichealthKit.Dispose();
                    }

                    picPortal = new PictureBox();
                    picPortal.Tag = "portal";
                    picPortal.BackColor = Color.Transparent;
                    picPortal.SizeMode = PictureBoxSizeMode.StretchImage;
                    picPortal.Size = new Size(66, 124);
                    picPortal.Image = Properties.Resources.portal;
                    picPortal.Location = new Point((ClientSize.Width - picPortal.Width) / 2, (ClientSize.Height - picPortal.Height) / 2);
                    Controls.Add(picPortal);

                    objectiveComplete = false;
                }

                //Checks if you touch portal and ending cutcene plays
                if (picPortal != null && picCharacter.Bounds.IntersectsWith(picPortal.Bounds))
                {
                    //Removes portal and ui on contact (gets ready for next scene)
                    tmrGame.Stop();
                    Controls.Remove(picPortal);
                    picPortal.Dispose();
                    
                    lblHealth.Visible = false;
                    lblKills.Visible = false;
                    lblObjective.Visible = false;
                    lblRoom.Visible = false;
                    pBarHealth.Visible = false;
                    picCharacter.Visible = false;

                    BackgroundImage = Properties.Resources.Black;

                    await Task.Delay(1500);

                    //Reveals sprites and changes background
                    BackgroundImage = Properties.Resources.EndBackground;
                    picEvil.Visible = true;
                    picEvil.Location = new Point(362, 140);
                    picCharacter.Visible = true;
                    picCharacter.Location = new Point((ClientSize.Width - picCharacter.Width) / 2, 350);

                    await Task.Delay(2000);

                    //Plays dialogue
                    cutscene2 = true;
                    gameState = GameState.OutGame;
                    dialogue = new DialogueManager(this);
                    dialogue.SetDialogue(this, DialogueState.End);
                    dialogue.ShowSentence();
                }

            }
            //Checks if you maximize the game
            if (WindowState == FormWindowState.Maximized)
            {
                tmrGame.Stop();
                BackgroundImage = Properties.Resources.RuleBreaker;

                foreach (PictureBox x in enemyList)
                    Controls.Remove(x);

                if (dialogue != null)
                {
                    Controls.Remove(dialogue.lblDialogue);
                    Controls.Remove(dialogue.picGuide);
                }

                lblTitle.Visible = false;
                lblGameOver.Visible = false;
                btnMainMenu.Visible = false;
                lblControlsAndTips.Visible = false;
                btnControls.Visible = false;
                btnBack.Visible = false;
                picCharacter.Visible = false;
                picEvil.Visible = false;
                lblHealth.Visible = false;
                lblKills.Visible = false;
                lblObjective.Visible = false;
                lblRoom.Visible = false;
                lblWarning.Visible = false;
                pBarHealth.Visible = false;
                btnStart.Visible = false;
                btnQuit.Visible = false;

                await Task.Delay(2000);
                Close();
            }
        }

        //Enemy Script
        public void SpawnEnemy()
        {
            int enemyToSpawn = rand.Next(1, 4); //Randomly chooses enemy to spawn

            int posX = rand.Next(24, ClientSize.Width - 50); //Gets random number for enemy x location inside form
            int posY = rand.Next(21, ClientSize.Height - 70); //Gets random number for enemy y location inside form

            if (Math.Abs(posX - picCharacter.Left) < 200) //Checks if horizontal Enemy spawnpoint is less than 200 pixels away from player
            {
                if (posX < picCharacter.Left)
                    posX -= 200; //Spawns enemy 200 more to the left if player is on the right side of screen
                else
                    posX += 200; //Spawns enemy 200 more to the right if player is on the Left side of screen
            }

            //Creates enemy 1 (sphere enemy)
            if (enemyToSpawn == 1)
            {
                PictureBox picEnemy1 = new PictureBox();
                picEnemy1.Left = posX;
                picEnemy1.Top = posY;

                picEnemy1.Image = Properties.Resources.Enemy1;
                picEnemy1.SizeMode = PictureBoxSizeMode.AutoSize;
                picEnemy1.BackColor = Color.Transparent;
                picEnemy1.Tag = "Evil Sphere";
                enemyList.Add(picEnemy1);


                Controls.Add(picEnemy1);
                picEnemy1.BringToFront();

            }
            else if (enemyToSpawn == 2) //Skeleton enemy
            {
                PictureBox picEnemy2 = new PictureBox();

                picEnemy2.Left = posX;
                picEnemy2.Top = posY;

                picEnemy2.Image = Properties.Resources.Enemy2;
                picEnemy2.SizeMode = PictureBoxSizeMode.AutoSize;
                picEnemy2.BackColor = Color.Transparent;
                picEnemy2.Tag = "Skeleton";
                enemyList.Add(picEnemy2);

                Controls.Add(picEnemy2);
                picEnemy2.BringToFront();
            }
            else if (enemyToSpawn == 3) //Ghost enemy
            {
                PictureBox picEnemy3 = new PictureBox();
                picEnemy3.Left = posX;
                picEnemy3.Top = posY;

                picEnemy3.Image = Properties.Resources.Enemy3;
                picEnemy3.SizeMode = PictureBoxSizeMode.AutoSize;
                picEnemy3.BackColor = Color.Transparent;
                picEnemy3.Tag = "Ghost";
                enemyList.Add(picEnemy3);

                Controls.Add(picEnemy3);
                picEnemy3.BringToFront();
            }
        }

        private async void startGame()
        {
            await Task.Delay(2000);
            //Reveals ui
            lblHealth.Visible = true;
            lblKills.Visible = true;
            lblObjective.Visible = true;
            lblRoom.Visible = true;
            health = 100;
            pBarHealth.Visible = true;
            lblObjective.Text = "Prove you are worthy: Defeat 80 enemies";

            enemyKillCount = 0;
            lblKills.Text = "Enemies Defeated: " + enemyKillCount;

            rooms = new Rooms();
            //Chooses cave background based on where you spawn (y spawn point is always 0)
            if (rooms.CurrentRoomX == 0 && rooms.CurrentRoomY == 0)
                BackgroundImage = Properties.Resources.CaveRD;
            else if (rooms.CurrentRoomX == rooms.RoomGridX && rooms.CurrentRoomY == 0)
                BackgroundImage = Properties.Resources.CaveLD;
            else if (rooms.CurrentRoomY == 0)
                BackgroundImage = Properties.Resources.CaveLRD;

            picCharacter.Visible = true;
            picCharacter.Location = new Point((ClientSize.Width - picCharacter.Width) / 2, (ClientSize.Height - picCharacter.Height) / 2);

            amountOfEnemies = rand.Next(2, 6); //Will spawn 2-5 enemies in first room
            for (int i = 0; i < amountOfEnemies; i++)
            {
                SpawnEnemy(); //Calls enemy spawn method
                picCharacter.BringToFront();
            }
            gameState = GameState.InGame;
        }

        public void GameOver()
        {
            tmrGame.Stop();
            gameState = GameState.OutGame;
            BackgroundImage = Properties.Resources.Black;

            //Deletes any health kit on screen when you get to this room
            if (pichealthKit != null)
            {
                Controls.Remove(pichealthKit);
                pichealthKit.Dispose();
            }

            //Deletes any left over pictureboxes on screen
            foreach (PictureBox x in enemyList)
                Controls.Remove(x);

            picCharacter.Visible = false;
            lblHealth.Visible = false;
            lblKills.Visible = false;
            lblObjective.Visible = false;
            lblRoom.Visible = false;
            lblWarning.Visible = false;
            pBarHealth.Visible = false;
            btnStart.Visible = false;
            btnQuit.Visible = false;

            lblGameOver.Visible = true;
            lblGameOver.Location = new Point(130, 100);
            btnMainMenu.Visible = true;
            btnMainMenu.Location = new Point(217, 276);
        }

        public void GameFinished() //Called at end of game after cutscene (if you win)
        {
            BackgroundImage = Properties.Resources.TitleBackground;
            picEvil.Visible = false;
            picCharacter.Visible = false;

            btnStart.Visible = true;
            btnQuit.Visible = true;
            btnControls.Visible = true;
            lblWarning.Visible = true;
            lblTitle.Visible = true;

            tmrGame.Start();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            BackgroundImage = Properties.Resources.TitleBackground;
            btnMainMenu.Visible = false;
            lblGameOver.Visible = false;
            btnControls.Visible = true;

            btnStart.Visible = true;
            btnQuit.Visible = true;
            lblWarning.Visible = true;
            lblTitle.Visible = true;

            tmrGame.Start();
        }

        private void btnControls_Click(object sender, EventArgs e)
        {
            btnControls.Visible = false;
            
            btnStart.Visible = false;
            btnQuit.Visible = false;
            lblWarning.Visible = false;
            lblControlsAndTips.Visible = true;
            lblControlsAndTips.Location = new Point(19, 38);
            lblTitle.Visible = false;
            btnBack.Visible = true;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            btnBack.Visible = false;

            btnControls.Visible = true;
            btnStart.Visible = true;
            btnQuit.Visible = true;
            lblWarning.Visible = true;
            lblTitle.Visible = true;
            lblControlsAndTips.Visible = false;
        }
    }
}