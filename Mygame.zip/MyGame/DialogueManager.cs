﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

enum DialogueState { None, Intro, End}

namespace MyGame
{
    class DialogueManager
    {
        /////Properties/Fields/////
        public string[] Sentences { get; set; }
        public int Index { get; private set; } = 0;
        public int SentenceLength { get; private set; }
        public int TypingSpeed { get; set; } = 40;
        public char[] Letters { get; private set; }

        public bool Next { get; private set; }
        public bool SpeechFinished { get; set; }

        public DialogueState state { get; set; }

        public Label lblDialogue { get; private set; } = new Label();
        public PictureBox picGuide { get; private set; } = new PictureBox();

        /////Constructor/////
        public DialogueManager(Form form)
        {
            state = DialogueState.Intro;
            lblDialogue.Size = new Size(780, 120);
            lblDialogue.Location = new Point((form.ClientSize.Width - lblDialogue.Width) / 2, 150);
            lblDialogue.TextAlign = (System.Drawing.ContentAlignment)HorizontalAlignment.Center;
            lblDialogue.Font = new Font("Comic Sans", 26f, FontStyle.Bold);
            lblDialogue.BackColor = Color.Gray;
            lblDialogue.ForeColor = Color.Black;
            form.Controls.Add(lblDialogue);
            lblDialogue.BringToFront();
        }

        /////Methods/////

        public void SetDialogue(Form form, DialogueState state)
        {
            //Shows a little picture that tells you what button to press to go to the next dialogue
            picGuide.BackColor = Color.DarkGray;
            picGuide.Image = Properties.Resources.z;
            picGuide.SizeMode = PictureBoxSizeMode.AutoSize;
            picGuide.Location = new Point(3, form.ClientSize.Height - picGuide.Height - 5);
            form.Controls.Add(picGuide);

            //Gets different dialogue depending on what part of the game your at 
            if (state == DialogueState.Intro)
            {
                Sentences = new string[8];
                Sentences[0] = "Once upon a time";
                Sentences[1] = "There was a human who went through many \nchallenges to gain power";
                Sentences[2] = "He would do anything it took \nto get stronger";
                Sentences[3] = "There was a legend that said anyone \nwho was able to conquer the \"Cave Of Evil\" \nwould gain the GREATEST of powers";
                Sentences[4] = "Naturally,|| this caught the humans attention.|| \nwith all the powers he already received plus \nthese powers...";
                Sentences[5] = "HE WOULD BECOME NEARLY INVINCIBLE";
                Sentences[6] = "So he found the cave where he would \nprove his worth";
                Sentences[7] = "And potentially gain power \nclose to that of a Gods";
            }

            else if (state == DialogueState.End)
            {
                lblDialogue.ForeColor = Color.Purple;
                lblDialogue.BackColor = Color.Black;
                lblDialogue.Size = new Size(500, 100);
                lblDialogue.Location = new Point((form.ClientSize.Width - lblDialogue.Width) / 2, 10);
                lblDialogue.Font = new Font("Comic Sans", 20f, FontStyle.Bold);

                Sentences = new string[8];
                Sentences[0] = "Hello human";
                Sentences[1] = "I am surprised to see an insignificant\n creature like you\n make it this far";
                Sentences[2] = "I suppose you came here for me to \ngrant you a small sum of my power";
                Sentences[3] = "I shall do that but...";
                Sentences[4] = "In return,||| \nY|O|U|R| |S|O|U|L| |I|S| |M|I|N|E";
                Sentences[5] = "You will no longer be\n a normal human...";
                Sentences[6] = "B|U|T| |A| |M|O|N|S|T|E|R";
                Sentences[7] = "It is done,|| now go reveal your\n new powers";
            }
        }

        public async void ShowSentence() //Used to output set dialogue
        {
            //Outputs the characters of the sentence one by one
            Next = false;
            foreach (char currentLetter in Sentences[Index].ToCharArray())
            {
                if (currentLetter == '|')
                    await Task.Delay(TypingSpeed * 2);
                else
                    lblDialogue.Text += currentLetter;

                //Delay between letters appearing
                await Task.Delay(TypingSpeed);
            }
            await Task.Delay(500);
            Next = true;

            if (Index == Sentences.Length - 1)
            {
                Next = false;
                SpeechFinished = true;

                picGuide.Dispose();
                picGuide = null;
            }
        }

        public void NextSentence()
        {
            if (Index < Sentences.Length - 1)
            {
                lblDialogue.Text = "";
                Index++;
                ShowSentence();
            }
        }

    }
}