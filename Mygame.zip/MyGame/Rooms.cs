﻿using System;

namespace MyGame
{
    class Rooms
    {
        /////Properties/Fields/////
        public int RoomGridX { get; private set; }
        public int RoomGridY { get; private set; }

        public int StartingRoomX { get; private set; }
        public int StartingRoomY { get; private set; }

        public int PortalRoomX { get; private set; }
        public int PortalRoomY { get; private set; }

        public int CurrentRoomX { get; set; }
        public int CurrentRoomY { get; set; }

        /////Constructors/////
        public Rooms() //Randomly sets amount of rooms in a grid shape, the starting room, and the boss room
        {
            Random rand = new Random();
            int x = rand.Next(7, 11);
            int y = rand.Next(7, 11);

            RoomGridX = x; RoomGridY = y;
            StartingRoomX = rand.Next(x); StartingRoomY = 0;
            PortalRoomX = rand.Next(x); PortalRoomY = rand.Next(y);
            CurrentRoomX = StartingRoomX; CurrentRoomY = StartingRoomY;
        }

        public Rooms(int xAmount, int yAmount) //Manually set grid of rooms. Starting room and boss room are still random
        {
            Random rand = new Random();

            RoomGridX = xAmount; RoomGridY = yAmount;
            StartingRoomX = rand.Next(xAmount); StartingRoomY = yAmount;
            PortalRoomX = rand.Next(xAmount); PortalRoomY = 0;
            CurrentRoomX = StartingRoomX; CurrentRoomY = StartingRoomY;
        }
    }
}