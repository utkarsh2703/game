﻿namespace MyGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnStart = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.tmrGame = new System.Windows.Forms.Timer(this.components);
            this.picCharacter = new System.Windows.Forms.PictureBox();
            this.lblRoom = new System.Windows.Forms.Label();
            this.pBarHealth = new System.Windows.Forms.ProgressBar();
            this.lblHealth = new System.Windows.Forms.Label();
            this.lblKills = new System.Windows.Forms.Label();
            this.lblObjective = new System.Windows.Forms.Label();
            this.lblWarning = new System.Windows.Forms.Label();
            this.lblGameOver = new System.Windows.Forms.Label();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.btnControls = new System.Windows.Forms.Button();
            this.lblControlsAndTips = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.picEvil = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picCharacter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEvil)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStart.Font = new System.Drawing.Font("Algerian", 27.75F, System.Drawing.FontStyle.Bold);
            this.btnStart.ForeColor = System.Drawing.Color.Orange;
            this.btnStart.Location = new System.Drawing.Point(265, 207);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(275, 93);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start Game";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnQuit.Font = new System.Drawing.Font("Algerian", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuit.ForeColor = System.Drawing.Color.Orange;
            this.btnQuit.Location = new System.Drawing.Point(265, 341);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(275, 93);
            this.btnQuit.TabIndex = 1;
            this.btnQuit.Text = "Quit Game";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // tmrGame
            // 
            this.tmrGame.Enabled = true;
            this.tmrGame.Interval = 20;
            this.tmrGame.Tick += new System.EventHandler(this.tmrGame_Tick);
            // 
            // picCharacter
            // 
            this.picCharacter.BackColor = System.Drawing.Color.Transparent;
            this.picCharacter.Image = global::MyGame.Properties.Resources.CharacterSprite;
            this.picCharacter.Location = new System.Drawing.Point(1157, 341);
            this.picCharacter.Name = "picCharacter";
            this.picCharacter.Size = new System.Drawing.Size(25, 65);
            this.picCharacter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCharacter.TabIndex = 0;
            this.picCharacter.TabStop = false;
            this.picCharacter.Tag = "Player";
            this.picCharacter.Visible = false;
            // 
            // lblRoom
            // 
            this.lblRoom.AutoSize = true;
            this.lblRoom.BackColor = System.Drawing.Color.PeachPuff;
            this.lblRoom.Location = new System.Drawing.Point(710, 445);
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.Size = new System.Drawing.Size(79, 13);
            this.lblRoom.TabIndex = 3;
            this.lblRoom.Text = "Room Location";
            this.lblRoom.Visible = false;
            // 
            // pBarHealth
            // 
            this.pBarHealth.BackColor = System.Drawing.SystemColors.Control;
            this.pBarHealth.ForeColor = System.Drawing.Color.Red;
            this.pBarHealth.Location = new System.Drawing.Point(70, 7);
            this.pBarHealth.Name = "pBarHealth";
            this.pBarHealth.Size = new System.Drawing.Size(100, 10);
            this.pBarHealth.TabIndex = 4;
            this.pBarHealth.Value = 100;
            this.pBarHealth.Visible = false;
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.BackColor = System.Drawing.Color.Transparent;
            this.lblHealth.Font = new System.Drawing.Font("MV Boli", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHealth.ForeColor = System.Drawing.Color.Lime;
            this.lblHealth.Location = new System.Drawing.Point(20, 2);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(47, 16);
            this.lblHealth.TabIndex = 5;
            this.lblHealth.Text = "Health";
            this.lblHealth.Visible = false;
            // 
            // lblKills
            // 
            this.lblKills.AutoSize = true;
            this.lblKills.BackColor = System.Drawing.Color.Transparent;
            this.lblKills.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKills.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblKills.Location = new System.Drawing.Point(193, 5);
            this.lblKills.Name = "lblKills";
            this.lblKills.Size = new System.Drawing.Size(130, 14);
            this.lblKills.TabIndex = 6;
            this.lblKills.Text = "Enemies Defeated: 0";
            this.lblKills.Visible = false;
            // 
            // lblObjective
            // 
            this.lblObjective.AutoSize = true;
            this.lblObjective.BackColor = System.Drawing.Color.Transparent;
            this.lblObjective.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObjective.ForeColor = System.Drawing.Color.Yellow;
            this.lblObjective.Location = new System.Drawing.Point(2, 445);
            this.lblObjective.Name = "lblObjective";
            this.lblObjective.Size = new System.Drawing.Size(249, 14);
            this.lblObjective.TabIndex = 7;
            this.lblObjective.Text = "Prove you are worthy: Defeat 80 enemies";
            this.lblObjective.Visible = false;
            // 
            // lblWarning
            // 
            this.lblWarning.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblWarning.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblWarning.Location = new System.Drawing.Point(610, 392);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(179, 66);
            this.lblWarning.TabIndex = 9;
            this.lblWarning.Text = "Do not maximize the form at any time. You will deeply regret it";
            // 
            // lblGameOver
            // 
            this.lblGameOver.AutoSize = true;
            this.lblGameOver.BackColor = System.Drawing.Color.Transparent;
            this.lblGameOver.Font = new System.Drawing.Font("Bauhaus 93", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGameOver.ForeColor = System.Drawing.Color.White;
            this.lblGameOver.Location = new System.Drawing.Point(863, 107);
            this.lblGameOver.Name = "lblGameOver";
            this.lblGameOver.Size = new System.Drawing.Size(543, 108);
            this.lblGameOver.TabIndex = 10;
            this.lblGameOver.Text = "GAME OVER";
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.Black;
            this.btnMainMenu.Font = new System.Drawing.Font("Bauhaus 93", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.ForeColor = System.Drawing.Color.White;
            this.btnMainMenu.Location = new System.Drawing.Point(904, 205);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(360, 130);
            this.btnMainMenu.TabIndex = 11;
            this.btnMainMenu.Text = "MainMenu";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // btnControls
            // 
            this.btnControls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnControls.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnControls.ForeColor = System.Drawing.Color.White;
            this.btnControls.Location = new System.Drawing.Point(23, 408);
            this.btnControls.Name = "btnControls";
            this.btnControls.Size = new System.Drawing.Size(104, 23);
            this.btnControls.TabIndex = 0;
            this.btnControls.Text = "Controls and tips";
            this.btnControls.UseVisualStyleBackColor = false;
            this.btnControls.Click += new System.EventHandler(this.btnControls_Click);
            // 
            // lblControlsAndTips
            // 
            this.lblControlsAndTips.AutoSize = true;
            this.lblControlsAndTips.BackColor = System.Drawing.Color.Transparent;
            this.lblControlsAndTips.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControlsAndTips.ForeColor = System.Drawing.Color.MintCream;
            this.lblControlsAndTips.Location = new System.Drawing.Point(877, 55);
            this.lblControlsAndTips.Name = "lblControlsAndTips";
            this.lblControlsAndTips.Size = new System.Drawing.Size(751, 361);
            this.lblControlsAndTips.TabIndex = 12;
            this.lblControlsAndTips.Text = resources.GetString("lblControlsAndTips.Text");
            this.lblControlsAndTips.Visible = false;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(23, 408);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(104, 23);
            this.btnBack.TabIndex = 13;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Visible = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // picEvil
            // 
            this.picEvil.BackColor = System.Drawing.Color.Transparent;
            this.picEvil.Image = global::MyGame.Properties.Resources.Evil;
            this.picEvil.Location = new System.Drawing.Point(991, 148);
            this.picEvil.Name = "picEvil";
            this.picEvil.Size = new System.Drawing.Size(70, 134);
            this.picEvil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEvil.TabIndex = 14;
            this.picEvil.TabStop = false;
            this.picEvil.Tag = "Antagonist";
            this.picEvil.Visible = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Haettenschweiler", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblTitle.Location = new System.Drawing.Point(158, 65);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(479, 101);
            this.lblTitle.TabIndex = 15;
            this.lblTitle.Text = "Power Seeker";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MyGame.Properties.Resources.TitleBackground;
            this.ClientSize = new System.Drawing.Size(794, 461);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnControls);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblControlsAndTips);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.lblGameOver);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.lblObjective);
            this.Controls.Add(this.lblKills);
            this.Controls.Add(this.lblHealth);
            this.Controls.Add(this.pBarHealth);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.lblRoom);
            this.Controls.Add(this.picCharacter);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.picEvil);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "Antagonist";
            this.Text = "Game";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.picCharacter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEvil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Timer tmrGame;
        private System.Windows.Forms.PictureBox picCharacter;
        private System.Windows.Forms.Label lblRoom;
        private System.Windows.Forms.ProgressBar pBarHealth;
        private System.Windows.Forms.Label lblHealth;
        private System.Windows.Forms.Label lblKills;
        private System.Windows.Forms.Label lblObjective;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.Label lblGameOver;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Button btnControls;
        private System.Windows.Forms.Label lblControlsAndTips;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.PictureBox picEvil;
        private System.Windows.Forms.Label lblTitle;
    }
}

